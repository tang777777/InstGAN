import warnings
import numpy as np 
import pandas as pd
from rdkit import Chem
from rdkit import rdBase
from rdkit import DataStructs
rdBase.DisableLog('rdApp.error')
warnings.filterwarnings("ignore")
from rdkit.Chem import PandasTools
from rdkit.Chem.rdMolDescriptors import GetMorganFingerprintAsBitVect
import os

import argparse
import pandas as pd
from rdkit.Chem import PandasTools
from rdkit.Chem.rdMolDescriptors import GetMorganFingerprintAsBitVect
import os
from mol_metrics import *
import logging
from rdkit.Chem import PandasTools, QED, Descriptors, rdMolDescriptors
import re

def mean_diversity(smiles):
    """
    args:
        - smiles: a list of SMILES strings

    returns:
        - average diversity score
    """
    scores = []
    df = pd.DataFrame({'smiles': smiles})
    PandasTools.AddMoleculeColumnToFrame(df, 'smiles', 'mol')
    fps = [GetMorganFingerprintAsBitVect(m, 4, nBits=2048) for m in df['mol'] if m is not None]
    for i in range(1, len(fps)):
        scores.extend(DataStructs.BulkTanimotoSimilarity(fps[i], fps[:i], returnDistance=True))
    
    return np.mean(scores)

def evaluation(generated_smiles, training_smiles):


    """
    args:
        - generated_smiles: a list of generated SMILES strings
        - training_smiles: training SMILES dataset

    returns:
        - validity: ratio of valid SMILES strings in generated SMILES stirngs
        - uniqueness: ratio of unique SMILES strings in the valid SMILES strings
        - novelty: ratio of novel SMILES strings in the unique SMILES strings
        - diversity: diversity score of the novel SMILES strings
    """

    # SMILES to molecules
    generated_mols = np.array([Chem.MolFromSmiles(s) for s in generated_smiles if len(s.strip())])
    
    if len(generated_mols) == 0:
        print('No SMILES data is generated, please pre-train the generator again!')
        return

    else:
        train_smiles = training_smiles

        valid_smiles = [Chem.MolToSmiles(mol) for mol in generated_mols if mol != None and mol.GetNumAtoms() > 1 and Chem.MolToSmiles(mol) != ' ']
        unique_smiles = list(set(valid_smiles))
        novel_smiles_unique = [smi for smi in unique_smiles if smi not in train_smiles]

        validity = len(valid_smiles)/len(generated_mols)
        uniqueness = len(unique_smiles)/len(valid_smiles)
        
        # novelty_unique based on novel_smiles_unique
        novelty_unique = len(novel_smiles_unique)/len(unique_smiles)

        # diversity based on novel_smiles_unique
        diversity = mean_diversity(novel_smiles_unique)

        # total based on validity, uniqueness and novelty_unique
        total = validity*uniqueness*novelty_unique

        # chemical properties based on novel_smiles_unique
        # Convert SMILES to Mol objects and filter out invalid entries
        novel_data = pd.Series(novel_smiles_unique).apply(Chem.MolFromSmiles).dropna()
        novel_data = novel_data[novel_data.apply(lambda x: x.GetNumAtoms() > 1)]
        

        if not novel_data.empty:
            # Compute QED, solubility, and SA scores
            novel_qed = novel_data.apply(QED.qed)
            novel_solubility = novel_data.apply(solubility)
            novel_sa = novel_data.apply(SA)

            # Compute means
            novel_mean_qed = novel_qed.mean() if not novel_qed.empty else 0
            novel_mean_solubility = novel_solubility.mean() if not novel_solubility.empty else 0
            novel_mean_sa = novel_sa.mean() if not novel_sa.empty else 0
        else: 
            novel_mean_qed = 0
            novel_mean_solubility = 0
            novel_mean_sa = 0





    return validity, uniqueness, novelty_unique, diversity, total, novel_mean_qed, novel_mean_solubility, novel_mean_sa


def generated_statistics(generated_smiles, training_smiles):

    validity, uniqueness, novelty_unique, diversity, total, novel_mean_qed, novel_mean_solubility, novel_mean_sa = evaluation(generated_smiles, training_smiles)
    
    # Format the metrics
    generated_metrics = {
        'Validity': f"{validity * 100:.2f}",
        'Uniqueness': f"{uniqueness * 100:.2f}",
        'Unique Novelty': f"{novelty_unique * 100:.2f}",
        'Diversity': f"{diversity:.2f}",
        'Total': f"{total * 100:.2f}",
        'QED': f"{novel_mean_qed:.2f}",
        'Solubility': f"{novel_mean_solubility:.2f}",
        'SA': f"{novel_mean_sa:.2f}",
    }
    
    return generated_metrics


def log_statistics(log_text, metric):
    # Define regular expressions for each metric
    regex_dict = {
        'Best Step': rf'Best {metric} models at step (\d+)',
        'Validity': rf'Best {metric} model Validity:\s+([\d.]+)',
        'Uniqueness': rf'Best {metric} model Uniqueness:\s+([\d.]+)',
        'Unique Novelty': rf'Best {metric} model Novelty:\s+([\d.]+)',
        'Total': rf'Best {metric} model Total:\s+([\d.]+)',
        'Diversity': rf'Best {metric} model Diversity:\s+([\d.]+)',
        'QED': rf'Best Total {metric} Novel Mean QED:\s+([\d.]+)',
        'Solubility': rf'Best {metric} model Novel Mean Solubility:\s+([\d.]+)',
        'SA': rf'Best {metric} model Novel Mean SA:\s+([\d.]+)',
        'Running Time': r'runing time: ([\d.]+)'
    }

    # Extract the metrics using regular expressions
    log_metrics = {}
    for key, regex in regex_dict.items():
        match = re.search(regex, log_text)
        if match:
            value = match.group(1)

            # Convert the running time from minutes to hours
            if key == 'Running Time':
                value = float(value) / 60.0
            
            log_metrics[key] = value
            
    return log_metrics

def check_metrics(generated_metrics, log_metrics):
    # Create a new dictionary to store combined metrics
    combined_metrics = {}

    # Compare and combine metrics
    for key, value in generated_metrics.items():
        if key in log_metrics:
            if value == log_metrics[key]:
                combined_metrics[key] = value
            else:
                print(f"Warning: Metric {key} has different values in generated_metrics ({value}) and log_metrics ({log_metrics[key]})")
        else:
            combined_metrics[key] = value

    # Add unique metrics from log_metrics to combined_metrics
    for key, value in log_metrics.items():
        if key not in combined_metrics:
            combined_metrics[key] = value

    return combined_metrics


def statistics_making(metric, folder_name):
    # Loop through each sub-folder under {parent_path}
    for s in os.listdir(parent_path):
        # Make sure to only read folders
        if os.path.isdir(os.path.join(parent_path, s)):
            generated_smiles = []
            file_path = os.path.join(parent_path, s, "logs", f"best_{metric}_generated_data.csv")

            with open(file_path, "r") as f:
                for line in f.readlines()[1:]:
                    generated_smiles.append(line.strip())


            # Call your function to read and format metrics
            generated_metrics = generated_statistics(generated_smiles, training_smiles)





            file_path2 = os.path.join(parent_path, s, "logs", "training_log.txt")

            # Read the text file
            with open(file_path2, 'r') as f2:
                log_text = f2.read()
            
            log_metrics = log_statistics(log_text, metric)

            combined_metrics = check_metrics(generated_metrics, log_metrics)
            # Mapping between the keys in combined_metrics and the DataFrame index names
            mapping = {
                'Validity': 'Validity(%)',
                'Uniqueness': 'Uniqueness(%)',
                'Unique Novelty': 'Unique Novelty(%)',
                'Diversity': 'Diversity',
                'Total': 'Total(%)',
                'QED': 'Unique Novel Mean QED',
                'Solubility': 'Unique Novel Mean Solubility',
                'SA': 'Unique Novel Mean SA',
                'Best Step': 'Best Step',
                'Running Time': 'Training Time(Hours)'
            }

            # Populate the DataFrame
            for key, value in combined_metrics.items():
                df_index = mapping.get(key)
                if df_index:
                    df.at[df_index, s] = value
    

        # Convert the entire DataFrame to float
    try:
        for col in df.columns:
            df[col] = df[col].astype(float)
    except ValueError:
        print("Could not convert all columns to float. Skipping this step.")

    # Convert 'Best Step' values to integer
    try:
        df.loc['Best Step'] = df.loc['Best Step'].astype(int)
    except KeyError as e:
        print("Row 'Best Step' not found in DataFrame. Error:", str(e))
    except ValueError as e:
        print("Could not convert row 'Best Step' values to integer. Error:", str(e))    





    
    # Transpose the DataFrame
    df_transposed = df.T  
       
    xlsx_path = f'Summary/{folder_name}.xlsx'

    if metric == 'Total':
        df_transposed.to_excel(xlsx_path, sheet_name=metric)


    else:
        with pd.ExcelWriter(xlsx_path, mode='a') as writer:
            df_transposed.to_excel(writer, sheet_name=metric)



if __name__ == "__main__":

    parser = argparse.ArgumentParser(description="Collect statistics from a folder.")
    
    parser.add_argument("--folder_name", required=True, help="The folder_name to collect statistics")

    args = parser.parse_args()


    data = []
    with open('zinc250k.csv', "r") as f:
        for line in f.readlines()[1:]:
            data.append(line.split(",")[1])

    # Training canonical SMILES
    training_smiles = [Chem.MolToSmiles(Chem.MolFromSmiles(sm)) for sm in data]
    training_smiles = list(set(training_smiles))


    # Initialize the DataFrame with row index
    metrics = ['Validity(%)', 'Uniqueness(%)', 'Unique Novelty(%)', 'Diversity', 'Total(%)', 'Unique Novel Mean QED','Unique Novel Mean Solubility', 'Unique Novel Mean SA', 'Best Step', 'Training Time(Hours)']
    df = pd.DataFrame(index=metrics)

    parent_path = os.path.join(args.folder_name, "Results", args.folder_name, "ew=0.022_gw=1e-05", "Alphas")
                             

    # Check if the folder exists
    if not os.path.exists('Summary'):
        os.makedirs('Summary')

    statistics_making('Total', args.folder_name) 
    statistics_making(args.folder_name, args.folder_name) 

        















































































