import argparse
import pandas as pd
from tabulate import tabulate

def e2l(file_path, sheet_name):
    # Read the Excel file into a Pandas DataFrame
    df = pd.read_excel(file_path, sheet_name)

    # Mapping DataFrame column names to LaTeX table column names
    mapping = {
        'Validity(%)': 'Validity(%)',
        'Uniqueness(%)': 'Uniqueness(%)',
        'Unique Novelty(%)': 'Novelty(%)',
        'Diversity': 'Diversity',
        'Total(%)': 'Total(%)',
        'Unique Novel Mean QED': 'QED',
        'Unique Novel Mean Solubility': 'Solubility',
        'Unique Novel Mean SA': 'SA',
        'Best Step': 'Best Step',
        'Training Time(Hours)': 'Training Time(Hours)'
    }

    # Rename columns based on mapping
    df.rename(columns=mapping, inplace=True)  # No need to reverse the dictionary

    # Drop the columns you don't need
    columns_to_drop = ['Best Step', 'Total(%)']
    df.drop(columns=columns_to_drop, inplace=True, errors='ignore')

    # Adjust column order
    if sheet_name in ['QED', 'Solubility', 'SA']:
        # Move the specific column (based on sheet name) to the second position
        rest_of_columns = [col for col in df.columns if col != sheet_name]
        column_order = [rest_of_columns[0], sheet_name] + rest_of_columns[1:]
    elif sheet_name == 'ALL':
        specific_columns = ['QED', 'Solubility', 'SA']
        rest_of_columns = [col for col in df.columns if col not in specific_columns]
        column_order = [rest_of_columns[0]] + specific_columns + rest_of_columns[1:]
    else:
        column_order = df.columns.tolist()
    df = df[column_order]
    
    # Format numeric columns to two decimal places
    for col in df.columns:
        if df[col].dtype in ['float64', 'float32']:
            df[col] = df[col].apply(lambda x: '{:.2f}'.format(x))
    
    # Convert the DataFrame to LaTeX format without the index
    latex_str = tabulate(df, headers='keys', tablefmt='latex', showindex=False)
    
    # LaTeX settings for table spacing
    spacing_commands = "\\renewcommand{\\arraystretch}{1.0}"  # Adjust the vertical space between rows
    spacing_commands += "\\setlength{\\tabcolsep}{1pt}"  # Adjust the horizontal space between columns (5pt is an example)
    
    # Add LaTeX caption centered above the table
    caption_str = "\\begin{center}\n" + f"\\textbf{{Detailed {sheet_name} Results}}\n" + "\\end{center}\n"
    latex_str = caption_str + latex_str
    
    # Add space between tables
    latex_str += "\n\\vspace{1cm}\n"
                        
    # Print LaTeX table
    print(latex_str)

    # Optionally, write LaTeX table to a .tex file
    with open("Summary/appendix_tables.tex", "a") as f:
        f.write(latex_str)

if __name__ == "__main__":
    # Initialize argument parser
    parser = argparse.ArgumentParser(description='Convert an Excel sheet to LaTeX table format.')
    
    # Add filepath argument with --file_path option
    parser.add_argument('--file_path', type=str, required=True, help='The path to the Excel file.')
    
    # Add sheetname argument with --sheet_name option
    parser.add_argument('--sheet_name', type=str, required=True, help='The name of the sheet to convert.')

    # Parse arguments
    args = parser.parse_args()

    # Execute e2l function
    e2l(args.file_path, args.sheet_name)