python zinc_statistics.py

python chembl_statistics.py