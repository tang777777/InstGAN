import pandas as pd
from rdkit import Chem
from mol_metrics import *
import numpy as np
import os






training_smiles = []

with open('../zinc250k.csv', "r") as f:
    for line in f.readlines()[1:]:
        training_smiles.append(line.split(",")[1])

# Training canonical SMILES
train_smiles = [Chem.MolToSmiles(Chem.MolFromSmiles(sm)) for sm in training_smiles]
train_smiles = list(set(train_smiles))

train_smiles = pd.Series(train_smiles)



train_smiles_sequence_lengths = train_smiles.str.len()
#print(train_smiles_sequence_lengths[0:5])
train_smiles_max_length = train_smiles_sequence_lengths.max()
train_smiles_min_length = train_smiles_sequence_lengths.min()
train_smiles_mean_length = train_smiles_sequence_lengths.mean()

print('train smiles max length: ', train_smiles_max_length)
print('train smiles min length: ', train_smiles_min_length)
print('train smiles mean length: ', train_smiles_mean_length)

import rdkit.Chem as Chem
from rdkit.Chem import PandasTools, QED, Descriptors, rdMolDescriptors

train_data = train_smiles.apply(Chem.MolFromSmiles)




# Compute QED, solubility, and SA scores
train_qed = train_data.apply(QED.qed)
train_solubility = train_data.apply(solubility)
train_sa = train_data.apply(SA)
train_drd2 = train_data.apply(DRD2)
# Compute means
train_mean_qed = train_qed.mean() 
train_mean_solubility = train_solubility.mean()
train_mean_sa = train_sa.mean()
train_mean_drd2 = train_drd2.mean()  

print('mean train_smiles qed: ', train_mean_qed)


print('mean train_smiles solubility: ', train_mean_solubility)



print('mean train_smiles sa: ', train_mean_sa)


print('mean train_smiles drd2: ', train_mean_drd2)


# Combine all the data into one DataFrame
combined_data = pd.concat([train_smiles.rename('SMILES'), 
                           train_qed.rename('QED'), 
                           train_solubility.rename('Solubility'), 
                           train_sa.rename('SA'), 
                           train_drd2.rename('DRD2')], axis=1)

# Save the combined data to a CSV file
output_file_path = 'zinc_combined_properties.csv'
combined_data.to_csv(output_file_path, index=False)

# Optionally, print out the path to the saved CSV file
print(f"Data saved to {output_file_path}")